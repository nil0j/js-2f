const CCAA = document.getElementById("ccaa")
const CCAA_LINK = "https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/ccaa.json"
const PROVINCE = document.getElementById("provincia")
const PROVINCE_LINK = "https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/provincias.json"
const POPULATION = document.getElementById("poblacion")
const POPULATION_LINK = "https://raw.githubusercontent.com/frontid/ComunidadesProvinciasPoblaciones/refs/heads/master/poblaciones.json"
let ccaaHashMap
let provinceHashMap

const IMAGE_CONTAINER = document.getElementById("image-container")

const FORM = document.getElementsByTagName("form")[0]

async function start() {
    fillCCAA()
    // fillSelectThroughApi(PROVINCE, PROVINCE_LINK)
    // fillSelectThroughApi(POPULATION, POPULATION_LINK)
    // res = await fetch(`https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=images&titles=${encodeURIComponent(POPULATION)}&gimlimit=10&prop=imageinfo&iiprop=url`)
}

async function fetchLink(link) {
    return fetch(link)
        .then((response) => {
            return response.json().then((data) => {
                return data;
            }).catch((err) => {
                console.log("can't fetch to " + link + ": " + err);
            })
        });
}

async function fillCCAA() {
    ccaaHashMap = {}
    resetOptions(CCAA)

    await fetchLink(CCAA_LINK).then(r => r.forEach(data => {
        let optionInstance = document.createElement("option")
        optionInstance.innerHTML = data.label
        CCAA.append(optionInstance)
        ccaaHashMap[data.label] = data.code
    }))
}

async function fillProvince(code) {
    provinceHashMap = {}
    resetOptions(PROVINCE)
    resetOptions(POPULATION)

    await fetchLink(PROVINCE_LINK).then(
        r => {r.forEach(data => {
        if (data.parent_code != code) return
        let optionInstance = document.createElement("option")
        optionInstance.innerHTML = data.label
        PROVINCE.append(optionInstance)
        provinceHashMap[data.label] = data.code
    })})
}

async function fillPopulation(code) {
    resetOptions(POPULATION)

    await fetchLink(POPULATION_LINK).then(r => r.forEach(data => {
        if (data.parent_code != code) return
        let optionInstance = document.createElement("option")
        optionInstance.innerHTML = data.label
        POPULATION.append(optionInstance)
        provinceHashMap[data.label] = data.code
    }))
}

async function resetOptions(element) {
    element.innerHTML = ""

    let defaultOption = document.createElement("option")
    defaultOption.disabled = true
    defaultOption.selected = true
    defaultOption.innerText = "Selecciona una opción"
    element.append(defaultOption)
}

CCAA.addEventListener("input", _ => {
    let ccaaCode = ccaaHashMap[CCAA.value]
    fillProvince(ccaaCode)
})

PROVINCE.addEventListener("input", _ => {
    let provinceCode = provinceHashMap[PROVINCE.value]
    fillPopulation(provinceCode)
})

FORM.addEventListener("submit", e => {
    e.preventDefault()
    let values = new FormData(FORM)

    let value
    const DEFAULT = "Selecciona una opción"

    value = CCAA.value

    if (PROVINCE.value != DEFAULT) {
        value = PROVINCE.value
    }

    if (POPULATION.value != DEFAULT) {
        value = POPULATION.value
    }

    spawnPics(value)
})

async function spawnPics(text){
    IMAGE_CONTAINER.innerHTML = ""
    pics = await getPics(text)

    if (pics == undefined) {
        let message = document.createElement("p")
        message.innerHTML = "no hay resultados <i>*c muere*</i>"
        message.style.color = "red"
        message.style.textAlign = "center"
        IMAGE_CONTAINER.append(message)
        return
    }

    for (let key in pics) {
        let img_box = document.createElement("div")
        img_box.className = "image-box"
        let img = document.createElement("img")
        let pic = pics[key];
        img.src = pic.imageinfo[0].url
        img_box.append(img)
        IMAGE_CONTAINER.append(img_box)
    }
}

async function getPics(text){
    res = await fetch(`https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=images&titles=${text}&gimlimit=10&prop=imageinfo&iiprop=url`)
    json = await res.json()
    return (json.query != undefined) ? json.query.pages : undefined
}

start()
